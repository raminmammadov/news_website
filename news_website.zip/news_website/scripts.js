document.addEventListener('DOMContentLoaded', function() {
    const articlesList = document.getElementById('articles-list');
    const articleForm = document.getElementById('article-form');
    const articleIdInput = document.getElementById('article_id');
    const titleInput = document.getElementById('title');
    const contentInput = document.getElementById('content');
    const authorInput = document.getElementById('author');
    const statusInput = document.getElementById('status');

    // Fetch articles and display in dashboard
    function fetchArticles() {
        fetch('fetch_articles.php')
            .then(response => response.json())
            .then(data => {
                articlesList.innerHTML = '';
                data.forEach(article => {
                    const articleDiv = document.createElement('div');
                    articleDiv.classList.add('article');
                    articleDiv.innerHTML = `
                        <h3>${article.title}</h3>
                        <p>${article.content}</p>
                        <p>Author: ${article.author}</p>
                        <p>Status: ${article.status}</p>
                        <button onclick="editArticle(${article.id})">Edit</button>
                        <button onclick="deleteArticle(${article.id})">Delete</button>
                    `;
                    articlesList.appendChild(articleDiv);
                });
            });
    }

    // Edit article
    window.editArticle = function(articleId) {
        fetch(`fetch_single_article.php?id=${articleId}`)
            .then(response => response.json())
            .then(article => {
                articleIdInput.value = article.id;
                titleInput.value = article.title;
                contentInput.value = article.content;
                authorInput.value = article.author;
                statusInput.value = article.status;
            });
    }

    // Delete article
    window.deleteArticle = function(articleId) {
        fetch(`delete_article.php?id=${articleId}`, { method: 'DELETE' })
            .then(response => response.text())
            .then(data => {
                alert(data);
                fetchArticles();
            });
    }

    // Fetch articles on page load
    fetchArticles();
});
