<?php
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, role FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->bind_result($id, $role);
    $stmt->fetch();

    if ($role) {
        $_SESSION['user_id'] = $id;
        $_SESSION['role'] = $role;
        header('Location: dashboard.php');
    } else {
        echo "Invalid username or password.";
    }

    $stmt->close();
}
?>
