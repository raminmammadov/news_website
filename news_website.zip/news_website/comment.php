<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $content = $_POST['content'];
    $article_id = $_POST['article_id'];

    $stmt = $conn->prepare("INSERT INTO comments (name, email, content, article_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $name, $email, $content, $article_id);
    $stmt->execute();
    $stmt->close();
    echo "Comment added successfully.";
}
?>
