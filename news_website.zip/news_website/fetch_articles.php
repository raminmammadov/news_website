<?php
include 'db.php';
session_start();

if (isset($_SESSION['role']) && ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'writer')) {
    $result = $conn->query("SELECT * FROM articles");
    $articles = [];

    while ($row = $result->fetch_assoc()) {
        $articles[] = $row;
    }

    echo json_encode($articles);
} else {
    echo "Unauthorized access.";
}
?>
