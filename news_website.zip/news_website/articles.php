<?php
include 'db.php';
session_start();

if (isset($_SESSION['role']) && ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'writer')) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $article_id = isset($_POST['article_id']) ? $_POST['article_id'] : null;
        $title = $_POST['title'];
        $content = $_POST['content'];
        $author = $_POST['author'];
        $status = $_POST['status'];
        $date = date("Y-m-d");

        if ($article_id) {
            // Update existing article
            $stmt = $conn->prepare("UPDATE articles SET title = ?, content = ?, author = ?, status = ?, date = ? WHERE id = ?");
            $stmt->bind_param("sssssi", $title, $content, $author, $status, $date, $article_id);
        } else {
            // Create new article
            $stmt = $conn->prepare("INSERT INTO articles (title, content, author, status, date) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $title, $content, $author, $status, $date);
        }

        $stmt->execute();
        $stmt->close();

        echo "Article saved successfully.";
    }
} else {
    echo "You are not authorized to perform this action.";
}
?>
