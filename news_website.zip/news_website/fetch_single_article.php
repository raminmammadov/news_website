<?php
include 'db.php';
session_start();

if (isset($_SESSION['role']) && ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'writer')) {
    $article_id = $_GET['id'];

    $stmt = $conn->prepare("SELECT * FROM articles WHERE id = ?");
    $stmt->bind_param("i", $article_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $article = $result->fetch_assoc();

    echo json_encode($article);
    $stmt->close();
} else {
    echo "Unauthorized access.";
}
?>
