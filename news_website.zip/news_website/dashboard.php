<?php
include 'db.php';
session_start();

if (!isset($_SESSION['role']) || ($_SESSION['role'] != 'admin' && $_SESSION['role'] != 'writer')) {
    header('Location: login.html');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Dashboard</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="about.html">About</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>
    <main>
        <h2>Manage Articles</h2>
        <form id="article-form" action="articles.php" method="post">
            <input type="hidden" name="article_id" id="article_id">
            <input type="text" name="title" id="title" placeholder="Title" required>
            <textarea name="content" id="content" placeholder="Content" required></textarea>
            <input type="text" name="author" id="author" placeholder="Author" required>
            <select name="status" id="status">
                <option value="draft">Draft</option>
                <option value="published">Published</option>
            </select>
            <button type="submit">Save</button>
        </form>

        <h2>Existing Articles</h2>
        <div id="articles-list">
            <!-- Articles will be dynamically loaded here -->
        </div>
    </main>
    <script src="scripts.js"></script>
</body>
</html>
