<?php
include 'db.php';
session_start();

if (isset($_SESSION['role']) && ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'writer')) {
    $article_id = $_GET['id'];

    $stmt = $conn->prepare("DELETE FROM articles WHERE id = ?");
    $stmt->bind_param("i", $article_id);
    $stmt->execute();

    echo "Article deleted successfully.";
    $stmt->close();
} else {
    echo "Unauthorized access.";
}
?>
